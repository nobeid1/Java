package edu.OrangeCoastCollege.CS170.Lyounis.IC26;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;
import java.util.jar.Attributes.Name;

import javax.print.DocFlavor.STRING;

public class HikingLogApp {
	static HashMap<Hike, Integer> hikingLog;
	static FileOutputStream file;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name, date, comment;
		int count = 0;
		double miles;
		Scanner consoleScanner = new Scanner(System.in);
		HashMap<String, Integer> hikingLog = new HashMap<>();
		
		try {
			ObjectOutputStream inputFile = new ObjectOutputStream(new FileOutputStream("HikingLog.dat"));
			inputFile.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("~~~~~~~~~~~~~~~~~~Welcome to the Hiking Log~~~~~~~~~~~~~~~~~~");

		do {
			System.out.print("Please enter name of hike completed (or 'quit' to exit): ");
			name = consoleScanner.nextLine();
			if (name.equalsIgnoreCase("quit"))
				break;
			count++;
			System.out.print("\nre-type it again please(or 'quit' to exit): ");
			name = consoleScanner.nextLine();
			if (name.equalsIgnoreCase("quit"))
				break;
			count++;
			System.out.print("Please enter the date of completion (MM/DD/YYYY)   : ");
			date = consoleScanner.nextLine();
			System.out.print("Please enter the miles completed                 : ");
			miles = consoleScanner.nextDouble();
			System.out.print("Please enter comments for the hike               : ");
			comment = consoleScanner.next();

			if (hikingLog.containsKey(name)) {

				int value = hikingLog.get(name);
				value++;
				hikingLog.put(name, value);
			} else {
				hikingLog.put(name, 1);
			}

		}  while (!name.equalsIgnoreCase("quit"));

		consoleScanner.close();

		int totalHikes = 0;
		for (int numHikes : hikingLog.values()) {
			totalHikes += numHikes;
		}

		int max = Integer.MIN_VALUE;
		String maxHikeName = "";
		for (String hike : hikingLog.keySet()) {
			if (hikingLog.get(hike) > max) {
				max = hikingLog.get(hike);
				maxHikeName = hike;
			}
		}

		System.out.println("\n~~~~~~~~~~~~~~~~~~Hiking Statistics~~~~~~~~~~~~~~~~~~");
		System.out.println("\nUnique Hikes Completed:\t" + (hikingLog.size()));
		System.out.println("Total Hikes Completed:\t" + (totalHikes));
		System.out.println("Most Frequent Hike:\t" + maxHikeName);

	}
}