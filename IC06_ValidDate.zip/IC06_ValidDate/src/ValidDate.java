import java.util.Scanner;

public class ValidDate
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
int month, day, year ;
String date, daypart, monthpart, yearpart;

Scanner consoleScanner= new Scanner(System.in);
System.out.println("Please enter a date in the form MM/DD/YYYY:");
date = consoleScanner.next();
monthpart = date.substring(0,2);
daypart = date.substring(3,5);
yearpart = date.substring(6);
// convert the strings to ints
month = Integer.parseInt(monthpart);
day = Integer.parseInt(daypart);
year = Integer.parseInt(yearpart);

if (month <1 || month > 12) 
    {
    System.err.println("Invalid month.");
    System.exit(0);
    }

    else  if ( month == 4 || month == 6 || month == 9 || month ==11  )
    {
        if (day> 30) 
        {
            System.err.println("Invalid month.");
        System.exit(0);
        }
    }
   
switch(month){
case 1:
case 3:
case 5:
case 7:
case 8:
case 10:
case 12:
	if(day > 31){ 
		System.err.println("Invalid day.");
		System.exit(0); }
	break;
case 2:
	if(day > 28){ 
		System.err.println("Invalid day.");
		System.exit(0); }
	break;

			}
    if (date.length() != 10 )
    {
        System.err.println("Invalid date.");
        System.exit(0);
    }
        if (year<0)
        {
            System.err.println("Invalid year.");
            System.exit(0);
        }
            else {
                System.out.println("Valid year.");
            
        }
    }    
}   
    
    
    


    


