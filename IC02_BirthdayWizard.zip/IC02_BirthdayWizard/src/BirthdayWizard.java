import java.util.Scanner;

public class BirthdayWizard  {

public static void main(String[] args) {
		// TODO Auto-generated method stub
	
Scanner consoleScanner=new Scanner(System.in);
int birthyear,currentage,futureage,futureyear;


System.out.println("Please enter your birth year...");

birthyear=consoleScanner.nextInt();
currentage= 2017-(birthyear);

System.out.println("You are " + +currentage + " years old.");


System.out.println("\nPlease enter a future age...");

futureage=consoleScanner.nextInt();

futureyear= (futureage-currentage)+ 2017;

System.out.print("You will be " + +futureage + " in the year " + +futureyear +".");


	}

}

