package edu.orangecoastcollege.cs170.nobeid1.ic22;


public class InvalidTimeException extends Exception {

	public InvalidTimeException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidTimeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidTimeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidTimeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidTimeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
