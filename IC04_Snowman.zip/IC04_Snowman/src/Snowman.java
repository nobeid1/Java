import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JApplet;



public class Snowman extends JApplet { 

	public void init() {
		
	setSize(300, 300);
	}
	public void paint(Graphics canvas)
	{
		Graphics2D g2 = (Graphics2D) canvas;
		g2.setStroke( new BasicStroke(1));
		canvas.setColor(Color.BLACK);
		canvas.drawOval(125,10, 50, 50);
		
		canvas.setColor(Color.BLACK);
		canvas.drawArc(139,33,20,20,180,185);
		
		canvas.setColor(Color.BLACK);
		canvas.drawOval(105,60,90,90);
		
		canvas.setColor(Color.BLACK);
		canvas.fillOval(135,20, 10,10);
		
		canvas.setColor(Color.BLACK);
		canvas.fillOval(155,20, 10,10);
		
		canvas.setColor(Color.BLACK);
		canvas.drawOval(83,150,130,130);
		
		
		
		
	}
		
		
}