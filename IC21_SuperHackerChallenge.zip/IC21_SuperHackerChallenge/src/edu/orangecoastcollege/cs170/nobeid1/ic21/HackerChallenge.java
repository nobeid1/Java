package edu.orangecoastcollege.cs170.nobeid1.ic21;

import java.util.Random;
import java.util.Scanner;

public class HackerChallenge {
	public static int a[][] = new int[9][9];
	public static int b[][] = new int[9][9];
	public static boolean solved = false;

	public static final int ROWS = 9;
	public static final int COLS = 9;
	public static int[][] workingPuzzle = new int[ROWS][COLS];

	public static void resetPuzzle() {
		// reset all values of working puzzle
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {
				 workingPuzzle[row][col]= b[row][col] ;

			}
		}
	}

	public static void printPuzzle() {
		
		System.out.println(" C 1 2 3 4 5 6 7 8 9");
		System.out.println("R  -----------------");

		for (int i = 0; i < ROWS; i++) {

			System.out.print((i + 1) + " |");
			for (int j = 0; j < COLS; j++) {

				if (workingPuzzle[i][j] == 0)
					System.out.print(". ");
				else
					System.out.print(workingPuzzle[i][j] + " ");
			}
			System.out.println();
		}

	}

	public static boolean gameIsWon() {
		for (int i = 0; i < ROWS; i++) {
			for (int j = 0; j < COLS; j++) {
				if (workingPuzzle[i][j] != a[i][j])
					return false;
			}
		}

		return true;
	}

	public static void main(String[] args) {
		String input;
		int row, col;
		Scanner consoleScanner = new Scanner(System.in);
		
		int p = 1;
		Random r = new Random();
		int i1 = r.nextInt(8);
		int firstval = i1;
		while (p == 1) {
			int x = firstval, v = 1;

			for (int i = 0; i < 9; i++) {
				for (int j = 0; j < 9; j++) {
					if ((x + j + v) <= 9)
						a[i][j] = j + x + v;
					else
						a[i][j] = j + x + v - 9;
					if (a[i][j] == 10)
						a[i][j] = 1;
				}
				x += 3;
				if (x >= 9)
					x = x - 9;
				if (i == 2) {
					v = 2;
					x = firstval;
				}
				if (i == 5) {
					v = 3;
					x = firstval;
				}

			}
		

			System.out.println("Hey! Lets play a game of sudoku: Take down the question and replace the .'s with your digits and complete the game by re-entering your answer\n");

			b[0][0] = a[0][0];
			b[8][8] = a[8][8];
			b[0][3] = a[0][3];
			b[0][4] = a[0][4];
			b[1][2] = a[1][2];
			b[1][3] = a[1][3];
			b[1][6] = a[1][6];
			b[1][7] = a[1][7];
			b[2][0] = a[2][0];
			b[2][4] = a[2][4];
			b[2][8] = a[2][8];
			b[3][2] = a[3][2];
			b[3][8] = a[3][8];
			b[4][2] = a[4][2];
			b[4][3] = a[4][3];
			b[4][5] = a[4][5];
			b[4][6] = a[4][6];
			b[5][0] = a[5][0];
			b[5][6] = a[5][6];
			b[6][0] = a[6][0];
			b[6][4] = a[6][4];
			b[6][8] = a[6][8];
			b[7][1] = a[7][1];
			b[7][2] = a[7][2];
			b[7][5] = a[7][5];
			b[7][6] = a[7][6];
			b[8][4] = a[8][4];
			b[8][5] = a[8][5];
			b[0][0] = a[0][0];
			b[8][8] = a[8][8];
			
			resetPuzzle();

			do {
				printPuzzle();
				System.out.println("What would you like to do ?");
				System.out.println("Set a square (S), Reset Puzzle (R), Quit (Q)");
				input = consoleScanner.next().toUpperCase();
				switch (input) {
				case "S":
					System.out.println("Which row(1-9) and whichcolum (1-9) do you want to change?");
					row = consoleScanner.nextInt() - 1;
					col = consoleScanner.nextInt() - 1;
					System.out.println("What should the Value (1-9)be?");
					workingPuzzle[row][col] = consoleScanner.nextInt();
					if (gameIsWon()) {
						// congratulate ( in your way) the User!
						int i;
						System.out.println("WOOHOOOO!!!! You solved it! CONGRATS!");
						for (i = 0; i <= 50; i++)
							System.out.println("CONGRATS!");

						System.exit(0);
					}

					break;
				case "R":
					resetPuzzle();
					break;
				case "Q":
					System.out.println("Thanks for playing!");
					System.exit(0);
					break;
				}

			} while (!input.equalsIgnoreCase("q"));

		}
	}

}