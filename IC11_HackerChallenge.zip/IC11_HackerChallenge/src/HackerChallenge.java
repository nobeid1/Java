

	
	import java.awt.Color;
	import java.awt.Graphics;

	import javax.swing.JApplet;
	public class HackerChallenge extends JApplet{
	
	    public static final int X_OFFSET = 130;
	    public static final int y_OFFSET = 120;
	public void init(){
	    setSize(655,480);
	    }
	public void paint(Graphics canvas){
		 
	    for(int row=0; row<=3;row++)
	    {
	    for(int col =0; col<=4;col++)
	    {
	    canvas.setColor(Color.ORANGE);
	    canvas.fillOval(12 + col*X_OFFSET, 1+row*y_OFFSET, 110, 110);
	    
	    canvas.setColor(Color.white);
	    canvas.fillOval(23 + col*X_OFFSET, 13+row*y_OFFSET, 88,88);
	    
	    canvas.setColor(Color.blue);
	    canvas.fillArc(26+ col*X_OFFSET, 17+row*y_OFFSET, 84,82,78,255);
	    canvas.setColor(Color.white);
	    canvas.fillOval(34+col*X_OFFSET, 26+row*y_OFFSET, 74,68);
	    canvas.setColor(Color.blue);
	    canvas.fillArc(36+col*X_OFFSET, 29+row*y_OFFSET, 72,61,85,255);
	    canvas.setColor(Color.white);
	    canvas.fillOval(45+col*X_OFFSET, 38+row*y_OFFSET, 59,50);
	    canvas.setColor(Color.blue);
	    canvas.drawString("Orange Coast College",8+col*X_OFFSET,119+row*y_OFFSET );
	    canvas.setColor(Color.blue);
	    canvas.fillArc(64+col*X_OFFSET, 17+row*y_OFFSET, 30,24,360,270);
	    canvas.setColor(Color.white);
	    canvas.fillOval(64+col*X_OFFSET, 25+row*y_OFFSET, 27,6);
	    canvas.setColor(Color.white);
	    canvas.fillOval(58+col*X_OFFSET, 26+row*y_OFFSET, 24,4);
	    canvas.setColor(Color.blue);
	    canvas.fillArc(64+col*X_OFFSET, 29+row*y_OFFSET, 30,17,275,270);
	    canvas.setColor(Color.white);
	    canvas.fillOval(84+col*X_OFFSET, 67+row*y_OFFSET, 22,14);
	    canvas.setColor(Color.white);
	    canvas.fillOval(84+col*X_OFFSET, 60+row*y_OFFSET, 25,14);
	}
	    
	
	}
	}
	}