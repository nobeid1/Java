import java.util.Random;
import java.util.Scanner;

public class Magic8Ball
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        String question, response;
        int Answer;
        Random rng = new Random();
        Scanner consoleScanner = new Scanner(System.in);
        do 
        {
        System.out.println("What question would like to ask for the eight ball?");
        question = consoleScanner.nextLine();
        Answer =rng.nextInt(8)+1;
        switch(Answer)
        {
        case 1:
        System.out.println("It is certain");
        break;
        case 2:
           System.out.println("It is decidedly so");      
           break;
        case 3:
            System.out.println("Most likely");
        break;
        case 4:
            System.out.println("Signs point to yes");
            break;
        case 5:
            System.out.println("Reply hazy, try again");
break;
        case 6:
System.out.println("Ask again later");
break;
        case 7:
System.out.println("Don't count on it");
break;
        case 8: 
            System.out.println("My sources say no");
break;
        }
 
        System.out.println("\nWould you like to ask another question?");
        response = consoleScanner.nextLine().toUpperCase();
        System.out.println("\n");
        } 
        while(response.startsWith("Y"));
        
         
       System.out.println("Thank you for playing the Magic 8 Ball.");
       consoleScanner.close();
    }

}
