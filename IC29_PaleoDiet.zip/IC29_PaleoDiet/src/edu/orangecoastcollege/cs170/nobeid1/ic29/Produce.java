package edu.orangecoastcollege.cs170.nobeid1.ic29;

import java.io.Serializable;

public class Produce extends PaleoFoods implements Serializable
{
private boolean mOrganic;

public Produce(int calories, int carbohydrates, String name,boolean organic)
{
    super();
    mCalories=calories;
    mCarbohydrates=carbohydrates;
    mName=name;
    mOrganic = organic;
}

public boolean getOrganic()
{
    return mOrganic;
}

public void setOrganic(boolean organic)
{
    mOrganic = organic;
}

@Override
public int hashCode()
{
    final int prime = 31;
    int result = 1;
    result = prime * result + (mOrganic ? 1231 : 1237);
    return result;
}

@Override
public boolean equals(Object obj)
{
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    Produce other = (Produce) obj;
    if (mOrganic != other.mOrganic) return false;
    return true;
}

@Override
public String toString()
{
    if(mOrganic==true){
        
    return "Organic Produce"+ ": " + mName+ ", " +mCalories+", "+mCarbohydrates ;}
        else {
            return "Produce"+ ": " + mName+ ", " +mCalories+", "+mCarbohydrates ;    
        }
}

}
