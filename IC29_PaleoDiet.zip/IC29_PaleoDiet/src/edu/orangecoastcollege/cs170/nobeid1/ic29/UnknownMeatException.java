package edu.orangecoastcollege.cs170.nobeid1.ic29;

public class UnknownMeatException extends Exception
{
public UnknownMeatException(String message){
    super(message);
}
public UnknownMeatException(){
    super("This is a mystery meat! Don't eat it!");
}
}
