package edu.orangecoastcollege.cs170.nobeid1.ic29;

import java.io.Serializable;

public abstract class PaleoFoods implements Serializable
{
protected int mCalories;
protected int mCarbohydrates;
protected String mName;
public int getCalories()
{
    return mCalories;
}
public void setCalories(int calories)
{
    mCalories = calories;
}
public int getCarbohydrates()
{
    return mCarbohydrates;
}
public void setCarbohydrates(int carbohydrates)
{
    mCarbohydrates = carbohydrates;
}
public String getName()
{
    return mName;
}
public void setName(String name)
{
    mName = name;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + this.mCalories;
	result = prime * result + this.mCarbohydrates;
	result = prime * result
			+ ((this.mName == null) ? 0 : this.mName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	PaleoFoods other = (PaleoFoods) obj;
	if (this.mCalories != other.mCalories)
		return false;
	if (this.mCarbohydrates != other.mCarbohydrates)
		return false;
	if (this.mName == null) {
		if (other.mName != null)
			return false;
	} else if (!this.mName.equals(other.mName))
		return false;
	return true;
}


}
