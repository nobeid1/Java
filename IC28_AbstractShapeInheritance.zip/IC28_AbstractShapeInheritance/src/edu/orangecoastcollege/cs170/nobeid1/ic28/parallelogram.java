package edu.orangecoastcollege.cs170.nobeid1.ic28;

import java.awt.Color;

public class parallelogram extends Shape2D
{

    private int mheight;
    private int mwidth;

        public parallelogram(Color color,int x, int y,int height, int width)
    {
        mcolor=color;
        mx=x;
        my=y;
        mheight = height;
        mwidth = width;
    }

        @Override
    public String toString()
    {
            String output="";
                        for(int i=0; i<mheight;i++){
                          
                            for(int k=0;k<i;k++){
                                output+=" ";}
                for(int j=0;j<mwidth;j++){
                   

                    output+="*";  
                }
             
                            
                            output+="\n";
            }
                
            output+= "The area of this parallelogram is "+ calculateArea()+ " square units.";
        return output; 
    }

        public int getMheight()
    {
        return mheight;
    }

    public void setMheight(int mheight)
    {
        this.mheight = mheight;
    }

    public int getMwidth()
    {
        return mwidth;
    }

    public void setMwidth(int mwidth)
    {
        this.mwidth = mwidth;
    }

        @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + mheight;
        result = prime * result + mwidth;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        parallelogram other = (parallelogram) obj;
        if (mheight != other.mheight) return false;
        if (mwidth != other.mwidth) return false;
        return true;
    }

        @Override
        public double calculateArea()
        {
            // TODO Auto-generated method stub
            return mwidth*mheight;
        }

    

}
