package edu.orangecoastcollege.cs170.nobeid1.ic28;

import java.awt.Color;
import java.io.Serializable;

public class Triangle extends Shape2D implements Serializable
{
private int mheight;
private int mbase;

    public Triangle(Color color,int x,int y,int height, int base)
{
    mcolor= color;
    mx=x;
    my=y;
    mheight = height;
    mbase = base;
    
}

    @Override
    public String toString()
    {
        String output="";
        for(int i=0;i<mbase;i++){
            for(int j=0;j<i+1;j++){
                output+="*";
            }
            output+="\n";
        }
        output+= "The area of this rectangle is "+ calculateArea()+ " square units.";
        return output; 
    }

    public int getMheight()
    {
        return mheight;
    }

    public void setMheight(int mheight)
    {
        this.mheight = mheight;
    }

    public int getMbase()
    {
        return mbase;
    }

    public void setMbase(int mbase)
    {
        this.mbase = mbase;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + mbase;
        result = prime * result + mheight;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (!super.equals(obj)) return false;
        if (getClass() != obj.getClass()) return false;
        Triangle other = (Triangle) obj;
        if (mbase != other.mbase) return false;
        if (mheight != other.mheight) return false;
        return true;
    }

    @Override
    public double calculateArea()
    {
        // TODO Auto-generated method stub
        return mheight*mbase/2;
    }

}
