package edu.orangecoastcollege.cs170.nobeid1.ic28;

import java.awt.Color;
import java.util.ArrayList;

public class Demo
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
    	ArrayList<Shape2D> ShapeList= new ArrayList<>();
    	ShapeList.add(new Rectangle(Color.BLACK,1,1,5,5));
ShapeList.add(new Triangle(Color.BLUE,1,1,5,5));
ShapeList.add(new parallelogram(Color.BLUE,1,1,5,5));
for(Shape2D shape: ShapeList){
    if(shape instanceof Rectangle)
    System.out.println(shape);
}
    }

}
