package edu.orangecoastcollege.cs170.nobeid1.ic28;

import java.awt.Color;
import java.io.Serializable;

public abstract class Shape2D implements Serializable
{
protected Color mcolor;
protected int mx;
protected int my;
public Color getMcolor()
{
    return mcolor;
}
public void setMcolor(Color mcolor)
{
    this.mcolor = mcolor;
}
public int getMx()
{
    return mx;
}
public void setMx(int mx)
{
    this.mx = mx;
}
public int getMy()
{
    return my;
}
public void setMy(int my)
{
    this.my = my;
}
@Override
public int hashCode()
{
    final int prime = 31;
    int result = 1;
    result = prime * result + ((mcolor == null) ? 0 : mcolor.hashCode());
    result = prime * result + mx;
    result = prime * result + my;
    return result;
}
@Override
public boolean equals(Object obj)
{
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    Shape2D other = (Shape2D) obj;
    if (mcolor == null)
    {
        if (other.mcolor != null) return false;
    }
    else if (!mcolor.equals(other.mcolor)) return false;
    if (mx != other.mx) return false;
    if (my != other.my) return false;
    return true;
}
//miscellaneous ABSTRACT method calculateArea
public abstract double calculateArea();

}
