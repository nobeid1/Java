import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AgeVerificationGUI extends JFrame
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
// Display a dialog to the user
       int response= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
        //response -1 = cancel, 0 means yeas, 1 means No
       switch (response) {
        case JOptionPane.CLOSED_OPTION:
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);
            break;
        case JOptionPane.NO_OPTION:
            JOptionPane.showMessageDialog(null, "Minor Detected", "You shall not pass!", JOptionPane.ERROR_MESSAGE);
            break;
        case JOptionPane.YES_OPTION:
           JOptionPane.showMessageDialog(null, "Proceed on adult!", "You are an adult", JOptionPane.INFORMATION_MESSAGE);
            break;
        
    }
    
}
}