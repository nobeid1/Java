
import java.text.NumberFormat;
import java.util.Scanner;


public class MortagePayment {

	
	public static void main(String[] args) {
		Scanner consoleScanner = new Scanner(System.in);
		NumberFormat Currency = NumberFormat.getCurrencyInstance();
		
		double MortagePayment, OutstandingBalance, Interest,Principal,InterestRate=0.04,AnnualRate=12;
		
		
		System.out.print("Please enter your mortage payment: $" );
		MortagePayment = consoleScanner.nextDouble();
		
		
		System.out.print("Please enter outstanding balance on mortage: $"  );
		OutstandingBalance= consoleScanner.nextDouble();
		System.out.println();
		
		System.out.println("Of your " + Currency.format(MortagePayment) + " mortage payment:" );
		
		Interest= OutstandingBalance*InterestRate/AnnualRate;
		System.out.println(Currency.format(Interest) + " goes to interest");
		
		Principal = MortagePayment - Interest;
		System.out.println(Currency.format(Principal) + " goes to principal");
		
		

	
		

	}

}
