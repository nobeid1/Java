import java.util.Scanner;

public class LexicographicOrdering
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
Scanner consoleScanner = new Scanner(System.in);
String p1,p2;
System.out.print("Player 1 (enter R for rock, P for paper, S for scissors): ");
p1 = consoleScanner.next().toUpperCase();
System.out.print("Player 2 (enter R for rock, P for paper, S for scissors): ");
p2 = consoleScanner.next().toUpperCase();

switch(p1)
{
    case "R": 
        switch (p2)
        {
            case "R":
                System.out.println("\nIt's a draw!");
                break;
            case "P":
                System.out.println("\nPlayer 2 wins!  Paper beats Rock. ");
                break;
            case "S":
                System.out.println("\nPlayer 1 wins!  Rock breaks Scissors.");
                default:
                    System.err.println("Enter R, P, or S");
                break;
        }
        break;

        
            case "S": 
                
                switch (p2)
                {
                    case "S":
                        System.out.println("\nIt's a draw!");
                        break;
                    case "P":
                        System.out.println("\nPlayer 1 wins!  Scissor cuts paper. ");
                        break;
                    case "R":
                        System.out.println("\nPlayer 2 wins!  Rock breaks Scissors.");
                        break;
                        default:
                            System.err.println("\nEnter R, P, or, S");
                            break;
                            
        }
                break;
    
      
            case "P": 
                switch (p2)
                {
                    case "P":
                        System.out.println("\nIt's a draw!");
                        break;
                    case "S":
                        System.out.println("\nPlayer 2 wins!  Scissors cut paper. ");
                        break;
                    case "R":
                        System.out.println("\nPlayer 1 wins!  Paper beats Rock.");
                    break;   
                    default:
                         
                        System.err.println("\nEnter R, P, or, S");
                        break;
        }
                default:
                System.err.println("\nEnter R, P, or, S");
                break;
    
       
    }

}
}