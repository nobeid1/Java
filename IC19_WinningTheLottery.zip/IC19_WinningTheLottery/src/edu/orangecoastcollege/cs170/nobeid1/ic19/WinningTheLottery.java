package edu.orangecoastcollege.cs170.nobeid1.ic19;

import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Random;

public class WinningTheLottery
{

    public static void main(String[] args)
    {
      int[] winningnumbers = new int[5];
      int[] guessnumbers = new int[winningnumbers.length];
      randomlyassignnumbers(winningnumbers);
      System.out.println("Today's Fantasy 5 winning Numbers Are:\n");
      System.out.println(Arrays.toString(winningnumbers));
      int spent=0;
      do{
          randomlyassignnumbers(guessnumbers);
          spent++;
      }while(howmanycorrect(winningnumbers, guessnumbers) != 5);
      NumberFormat currency = NumberFormat.getCurrencyInstance();

      System.out.println("\nHOORAY! You won the Fantasy 5 Lottery!!");
      System.out.println("You only had to spend " + currency.format(spent) + " dollars to win :)");
    }
    public static int howmanycorrect(int[] array1,int[] array2){
        int correct=0;
        for(int i=0; i<array1.length;i++)
        {
            if(array1[i]== array2[i])
                correct++;

        }
        return correct;
    }
public static void randomlyassignnumbers(int[] anyArray){
    Random rng = new Random();
    for(int i = 0; i < anyArray.length; i++){
        anyArray[i]= rng.nextInt(36)+1;
    }

}
}
