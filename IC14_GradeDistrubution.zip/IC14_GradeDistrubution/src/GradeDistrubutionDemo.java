import java.text.DecimalFormat;
public class GradeDistrubutionDemo {
	

	

	
		public static void main(String[] args) {
			GradeDistribution grade = new GradeDistribution(18, 6, 4, 7, 9);
			
			DecimalFormat ZeroDp = new DecimalFormat("#");
			
			
			System.out.println(grade.getPercentBs());
			System.out.println(ZeroDp.format(grade.getPercent("a")) + "%");
			
			System.out.println(grade);
			
		}

	}

