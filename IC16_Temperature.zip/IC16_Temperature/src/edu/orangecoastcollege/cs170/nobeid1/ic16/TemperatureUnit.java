package edu.orangecoastcollege.cs170.nobeid1.ic16;

public enum TemperatureUnit {
	
	    FAHRENHEIT,
	    CELSIUS
	}

