import java.text.DecimalFormat;
import java.util.Scanner;

public class BasalMetabolicRatePartDeux
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
double weight,height,age,bmr,bars,barcalories = 230.0;

        
        DecimalFormat zeroDPs = new DecimalFormat("0");
        
        Scanner consoleScanner= new Scanner(System.in);
        System.out.println("Please enter your weight (lb): ");
        weight= consoleScanner.nextDouble();
        
        System.out.println("Please enter your height (in): ");
        height= consoleScanner.nextDouble();
        
        System.out.println("Please enter your age in years: ");
        age= consoleScanner.nextDouble();
        
        System.out.println("Please enter Male or Female:");
        String gender;
        gender = consoleScanner.next();
        System.out.println("Please enter the number corresponding with your activity factor:");
        System.out.println("1. Sedentary (not active)");
        System.out.println("2. Somewhat active (exercise occasionally)");
        System.out.println("3. Active (exercise 3-4 times per week)");
        System.out.println("4. Highly Active( exercise every day)");
        int activityFactor;
        activityFactor = consoleScanner.nextInt();
        if (gender.equalsIgnoreCase("female") || gender.toLowerCase().startsWith("f")) {
          
            bmr= 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age); 
            
        }
        else { 
            bmr= 66 +(6.23 * weight)+(12.7 * height)-(6.8 * age);
        }
       if (activityFactor == 1){
           bmr *= 1.2;
           
       }
       else if (activityFactor == 2){
    bmr*= 1.3;
    
}
       else if (activityFactor == 3){
           bmr *= 1.4;
           
 }
       else if (activityFactor == 4){
           bmr *= 1.5;
           
       }
       bars= bmr/ barcalories;
        System.out.print("As a " +gender + " your BMR x Activity Factor is " + zeroDPs.format(bmr) + " and you need to eat " + zeroDPs.format(bars) + " chocolate bars to maitain this amount of calories."); 
        
        
    }

}
