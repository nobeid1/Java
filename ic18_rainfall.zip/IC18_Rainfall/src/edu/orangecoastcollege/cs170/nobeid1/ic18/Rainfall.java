package edu.orangecoastcollege.cs170.nobeid1.ic18;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class Rainfall
{

    public static void main(String[] args)
    {
        DecimalFormat twoDps= new DecimalFormat("0.00");
String[] months = {"January", "February","March","April","May","June","July","August","September","October","November","December"};
double[] rainfall= new double[months.length];
double average,sum=0, maximum=0,minimum=0;
Scanner consoleScanner = new Scanner (System.in);
for(int i=0; i<months.length; i++)
{
   System.out.print("Enter rainfall amount (in inches) for " +months[i]+" >> " );
rainfall[i] = consoleScanner.nextDouble();
sum += rainfall[i];
    }
Arrays.sort(rainfall);
average=sum/rainfall.length;
System.out.println("\nTotal Rainfall for the year(in inches)  " + twoDps.format(sum));
System.out.println("Average Rainfall for the year(in inches) " + twoDps.format(average));
System.out.println("Maximum monthly Rainfall for the year(in inches) " +twoDps.format(rainfall[months.length-1]));
System.out.println("Minimum monthly Rainfall for the year(in inches) " +twoDps.format(rainfall[0]));

}
}