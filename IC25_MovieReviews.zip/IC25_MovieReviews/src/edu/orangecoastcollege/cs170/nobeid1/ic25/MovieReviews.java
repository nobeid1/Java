package edu.orangecoastcollege.cs170.nobeid1.ic25;
//TODO Auto-generated method stub
		import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.util.Scanner;
public class MovieReviews {

	

		    public static void main(String[] args)throws FileNotFoundException
		    {

		    		Scanner fileScanner = new Scanner(new File("MovieReviews.txt"));
		    		countReviews(fileScanner);
		    		}

		    		// Counts total lines and words in the input scanner.
		    		public static void countReviews(Scanner input) {
				        DecimalFormat oneDP = new DecimalFormat("#.0");

		    		double ReviewCount = 0.0, total =0.0;
		    		

		    	
		    		while (input.hasNext()) { // tokens in line
		    		double Review=input.nextDouble();
		    		ReviewCount++;
		    		total+=Review;
		    		}
		    		

		    		
		    		System.out.println("# of reviews: " + ReviewCount);
		    		System.out.println("average # of reviews: " + oneDP.format(total/ReviewCount));
		    		}
		    		}
		    		
		    

		
		    

