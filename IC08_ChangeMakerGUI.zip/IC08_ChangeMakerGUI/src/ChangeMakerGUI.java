import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ChangeMakerGUI extends JFrame
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        int cents, quarters, dimes, nickels, pennies;
        Scanner consoleScanner = new Scanner(System.in);

        String response = JOptionPane.showInputDialog(null,"Enter a whole number from 1 to 99.\n" +
        "I will find a combination of coins to equal that amount of change.");
        //Convert the string response into int
        cents = Integer.parseInt(response);
     
        
        // Change given in coins
        quarters = cents / 25;
        cents = cents % 25;
        dimes = cents / 10;
        cents = cents % 10;
        nickels = cents / 5;
        pennies = cents % 5; // Left over after filtering out nickels is the amount of pennies

        JOptionPane.showMessageDialog(null, 
                response + " cents in coins can be given as: \n"
                 + quarters + " quarter(s)\n" 
                + dimes + " dime(s)\n" 
                + nickels + " nickel(s)\n"
                + pennies + " penny(ies)");
        
    }


    }


