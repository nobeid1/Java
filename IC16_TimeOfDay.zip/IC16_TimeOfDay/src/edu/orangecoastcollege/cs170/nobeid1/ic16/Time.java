package edu.orangecoastcollege.cs170.nobeid1.ic16;

import java.text.DecimalFormat;

public class Time
{
    private int mHour;
    private int mMinute;
    public Time(int hour, int minute)
    {
        super();
        mHour = hour;
        mMinute = minute;
    }
    public int getHour()
    {
        return mHour;
    }
    public void setHour(int hour)
    {
        mHour = hour;
    }
    public int getMinute()
    {
        return mMinute;
    }
    public void setMinute(int minute)
    {
        mMinute = minute;
    }
    @Override
    public String toString()
    {
        DecimalFormat twoDigits= new DecimalFormat("00");
        String output = "Time [" + twoDigits.format(mHour) + ":" + twoDigits.format(mMinute) +" ";
        if(isAm())
            output += "AM]";
        else
            output += "PM]";
        return output;
              
    }
    
    public Time()
    {
        this(0,0);
           }
    public Time(Time other)
    {
        this(other.mHour, other.mMinute);
    }
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Time other = (Time) obj;
        if (mHour != other.mHour) return false;
        if (mMinute != other.mMinute) return false;
        return true;
    }
   
    
    private boolean isValid(int hour, int minute){
        if(hour < 0 || hour > 23)
            return false;
        if(minute < 0 || minute > 59)
            return false;
        return true;
    }

    public void setTime(int hour, int minute){
        if(isValid(hour, minute))
            throw new IllegalArgumentException ("Error. Hour must be between 0 and 23.");
        
        this.mHour = hour;
        this.mMinute = minute;
    }
    
    public boolean isAm(){
        return mHour < 12 ;
    }
    
    }

      

