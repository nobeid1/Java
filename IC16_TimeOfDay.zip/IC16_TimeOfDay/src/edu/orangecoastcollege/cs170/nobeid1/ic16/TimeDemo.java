package edu.orangecoastcollege.cs170.nobeid1.ic16;

public class TimeDemo
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
Time clock1= new Time(12, 12);
Time clock2= new Time(clock1);
Time midnight = new Time();
System.out.println(clock1);
System.out.println(clock2);
System.out.println(midnight);
if(clock1.equals(clock2))
    System.out.println("They are the same time!");
else
    System.out.println("They are different time!");
clock2.setHour(9);
clock2.setMinute(24);
System.out.println(clock1);
System.out.println(clock2);
if(clock1.equals(clock2))
    System.out.println("They are the same time!");
else
    System.out.println("They are different time!");
    }

}
