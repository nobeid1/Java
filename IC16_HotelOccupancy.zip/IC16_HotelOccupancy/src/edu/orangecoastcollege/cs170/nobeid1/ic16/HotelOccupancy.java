package edu.orangecoastcollege.cs170.nobeid1.ic16;

public class HotelOccupancy
{
private int mnumber;
private int mpeople;
private static int sTotalOccupancy = 0;
public HotelOccupancy(int mnumber, int mpeople)
{
    super();
    this.mnumber = mnumber;
    this.mpeople = mpeople;
    HotelOccupancy.sTotalOccupancy += mpeople;
}

public int getMpeople()
{
    return mpeople;
}
public int getTotalOccupancy()
{
    return sTotalOccupancy;
}


public static void setsTotalOccupancy(int sTotalOccupancy)
{
    HotelOccupancy.sTotalOccupancy = sTotalOccupancy;
}

@Override

public String toString()
{
    return "HotelRoom [Room Number=" + mnumber + ", People In Room=" + mpeople + ", TotalOccupancy="
            + sTotalOccupancy + "]";
}
@Override
public boolean equals(Object obj)
{
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    HotelOccupancy other = (HotelOccupancy) obj;
    if (mnumber != other.mnumber) return false;
    if (mpeople != other.mpeople) return false;
    return true;
}

public boolean addtoNumber(int people){
    if(people + mpeople > 4)
        return false;
    else
           sTotalOccupancy += people;
    mpeople += people;
    return true ;
}

public boolean removeFromRoom(int people){
    if(mpeople -people  <= -1)
      return false;
   else
        mpeople -=  people ;
        sTotalOccupancy -= people;
        return true;
    
}
}
