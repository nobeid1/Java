package edu.orangecoastcollege.cs170.nobeid1.ic16;

public class HotelOccupancyDemo
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
HotelOccupancy hotelroom1 = new HotelOccupancy(125, 3);
HotelOccupancy hotelroom2 = new HotelOccupancy(201, 2);
System.out.println(hotelroom1);
System.out.println(hotelroom2);
hotelroom1.addtoNumber(1);
hotelroom2.removeFromRoom(2);

System.out.println(hotelroom1);
System.out.println(hotelroom2);
    }

}
