package edu.orangecoastcollege.cs170.nobeid1.ic18;


	import java.text.DecimalFormat;
import java.util.Scanner;

public class HackerChallenge {
	
	    
	 
	    public static double age;
	    public static int recommended = 0, notRecommended = 0, appropiate = 0;
	    
	  
	    public static void main(String[] args)
	    {
	        final String[] DAYS = {"Sunday", "Monday","Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
	        
	        Scanner consoleScanner = new Scanner(System.in);
	        DecimalFormat twoDP = new DecimalFormat("#.00");
	        
	        double[] slept = new double[DAYS.length];
	        int counter = 0;
	        double total = 0;
	        	        System.out.print("Please Enter your age: ");
	        age = consoleScanner.nextDouble();
	        
	        
	        for(String day:DAYS){
	            System.out.print("Enter number of hours slept on " + day + ": ");
	            slept[counter] = consoleScanner.nextInt();
	            total +=slept[counter];
	            counter++;
	        }
	        consoleScanner.close();
	        System.out.println("\nTotal Number of hours slept last week: " + total
	                + "\nAverage number of hours slept per night: " + twoDP.format(total/slept.length) );
	        
	       
	        
	    if(age >= 0 && age <= 0.3 ){
				System.out.print("\nAs a Newborn, your sleep health (on average) is ");
				 for(double night: slept){
			            if(night >= 14 && night <= 17){
			                recommended++;
			            }else if(night <11 || night > 19)
			            	notRecommended++ ;
			            else
			            	appropiate++ ;
			        }
				        if (total/slept.length >= 14 && total/slept.length <= 17)
				            System.out.println("\"recommended\"");
				        else if (total/slept.length < 11 || total/slept.length > 19)
				            System.out.println("\"not recommended\"");
				        else
				            System.out.println("\"appropriate\"");
				        consoleScanner.close();
	        }else if(age >= 0.4 && age <= 0.11){
	        	for(double night: slept){
		            if(night >= 12 && night <= 15){
		                recommended++;
		            }else if(night <10 && night > 18)
		            	notRecommended++ ;
		            else
		            	appropiate++ ;
		        }
	            	System.out.print("\nAs an Infant, your sleep health (on average) is ");
				        if (total/slept.length >= 12 && total/slept.length <= 15)
				            System.out.println("\"recommended\"");
				        else if (total/slept.length < 10 || total/slept.length > 18)
				            System.out.println("\"not recommended\"");
				        else
				            System.out.println("\"appropriate\"");
				        consoleScanner.close();
	        }
	        else if(age >= 1.0 && age <= 2.0 ){
	        	for(double night: slept){
		            if(night >= 11 && night <= 14){
		                recommended++;
		            }else if(night <9 || night > 16)
		            	notRecommended++ ;
		            else
		            	appropiate++ ;
		        }
	        	System.out.print("\nAs a toddler, your sleep health (on average) is ");
		        if (total/slept.length >= 11 && total/slept.length <= 14)
		            System.out.println("\"recommended\"");
		        else if (total/slept.length < 9 || total/slept.length > 16)
		            System.out.println("\"not recommended\"");
		        else
		            System.out.println("\"appropriate\"");
		        consoleScanner.close();

	        }else if(age >= 3.0 && age <= 5.0 ){
	        	System.out.print("\nAs a preschooler, your sleep health (on average) is ");
	        	for(double night: slept){
		            if(night >= 10 && night <= 13){
		                recommended++;
		            }else if(night <8 || night > 14)
		            	notRecommended++ ;
		            else
		            	appropiate++ ;
		        }
		        if (total/slept.length >= 10 && total/slept.length <= 13)
		            System.out.println("\"recommended\"");
		        else if (total/slept.length < 8|| total/slept.length > 14)
		            System.out.println("\"not recommended\"");
		        else
		            System.out.println("\"appropriate\"");
		        consoleScanner.close();

	        }else if (age >= 6 && age <= 13 ){
	        	System.out.print("\nAs a School-aged child, your sleep health (on average) is ");
	        	for(double night: slept){
		            if(night >= 9 && night <= 11){
		                recommended++;
		            }else if(night <7 || night > 12)
		            	notRecommended++ ;
		            else
		            	appropiate++ ;
		        }
		        if (total/slept.length >= 9 && total/slept.length <= 11)
		            System.out.println("\"recommended\"");
		        else if (total/slept.length < 7 || total/slept.length > 12)
		            System.out.println("\"not recommended\"");
		        else
		            System.out.println("\"appropriate\"");
		        consoleScanner.close();

	        }else if (age >= 14 && age <= 17){
	        	System.out.print("\nAs a teenager, your sleep health (on average) is ");
	        	for(double night: slept){
		            if(night >= 8 && night <= 10){
		                recommended++;
		            }else if(night <7 || night > 11)
		            	notRecommended++ ;
		            else
		            	appropiate++ ;
		        }
		        if (total/slept.length >= 8 && total/slept.length <= 10)
		            System.out.println("\"recommended\"");
		        else if (total/slept.length < 7 || total/slept.length > 11)
		            System.out.println("\"not recommended\"");
		        else
		            System.out.println("\"appropriate\"");
		        consoleScanner.close();

	        }else if (age >= 18 && age <= 25 ){
	        	System.out.print("\nAs a young adult, your sleep health (on average) is ");
	        	for(double night: slept){
		            if(night >= 7 && night <= 9){
		                recommended++;
		            }else if(night <6 || night > 11)
		            	notRecommended++ ;
		            else
		            	appropiate++ ;
		        }
		        if (total/slept.length >= 7 && total/slept.length <= 9)
		            System.out.println("\"recommended\"");
		        else if (total/slept.length < 6 || total/slept.length > 11)
		            System.out.println("\"not recommended\"");
		        else
		            System.out.println("\"appropriate\"");
		        consoleScanner.close();

	        }else if (age >= 26 && age <= 64 ){
	        	System.out.print("\nAs an adult, your sleep health (on average) is ");
	        	for(double night: slept){
		            if(night >= 7 && night <= 9){
		                recommended++;
		            }else if(night <6 || night > 11)
		            	notRecommended++ ;
		            else
		            	appropiate++ ;
		        }
		        if (total/slept.length >= 7 && total/slept.length <= 9)
		            System.out.println("\"recommended\"");
		        else if (total/slept.length < 6 || total/slept.length > 11)
		            System.out.println("\"not recommended\"");
		        else
		            System.out.println("\"appropriate\"");
		        consoleScanner.close();

	        }else {
	        	System.out.print("\nAs an older adult, your sleep health (on average) is ");
	        	for(double night: slept){
		            if(night >= 7 && night <= 8){
		                recommended++;
		            }else if(night <5 || night > 9)
		            	notRecommended++ ;
		            else
		            	appropiate++ ;
		        }
		        if (total/slept.length >= 7 && total/slept.length <= 8)
		            System.out.println("\"recommended\"");
		        else if (total/slept.length < 5 || total/slept.length > 9)
		            System.out.println("\"not recommended\"");
		        else
		            System.out.println("\"appropriate\"");
		        consoleScanner.close();

	        }
	    System.out.println("\nAccording to the NSF, you slept: \n" + 
                recommended + (recommended == 1 ? " night":" nights") + " of \"recommended\" Sleep.\n" + 
                appropiate + (appropiate == 1 ? " night":" nights") + " of \"appropiate\" Sleep.\n" + 
              
                notRecommended + (notRecommended == 1 ? " night":" nights") + " of \"not recommended\" Sleep.");

	    }

	}

	
		

