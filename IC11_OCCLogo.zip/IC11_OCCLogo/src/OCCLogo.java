import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;

public class OCCLogo extends JApplet
{
    public static final int X_OFFSET = 130;
    public static final int y_OFFSET = 120;
public void init(){
    setSize(655,480);
    }
public void paint(Graphics canvas){
   // Loop across colimn
    for(int row=0; row<=3;row++)
    {
    for(int col =0; col<=4;col++)
    {
    canvas.setColor(Color.ORANGE);
    canvas.fillOval(10 + col*X_OFFSET, 0+row*y_OFFSET, 102, 102);
    
    canvas.setColor(Color.white);
    canvas.fillOval(17 + col*X_OFFSET, 7+row*y_OFFSET, 88,88);
    
    canvas.setColor(Color.blue);
    canvas.fillArc(20+ col*X_OFFSET, 9+row*y_OFFSET, 84,82,78,255);
    canvas.setColor(Color.white);
    canvas.fillOval(27+col*X_OFFSET, 18+row*y_OFFSET, 73,70);
    canvas.setColor(Color.blue);
    canvas.fillArc(29+col*X_OFFSET, 20+row*y_OFFSET, 65,65,78,255);
    canvas.setColor(Color.white);
    canvas.fillOval(37+col*X_OFFSET, 29+row*y_OFFSET, 53,53);
    canvas.setColor(Color.blue);
    canvas.drawString("Orange Coast College",10+col*X_OFFSET,110+row*y_OFFSET );
}
}
}
}