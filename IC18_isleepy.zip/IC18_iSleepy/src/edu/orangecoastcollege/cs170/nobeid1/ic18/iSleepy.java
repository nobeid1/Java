package edu.orangecoastcollege.cs170.nobeid1.ic18;

import java.util.Scanner;

public class iSleepy
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        String[] days = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
        double[] hours = new double[days.length];
        double sum = 0, average;
        int recommended = 0, notRecommended = 0, appropiate = 0;
        Scanner consoleScanner = new Scanner(System.in);
        for (int i = 0; i < days.length; i++)
        {
            System.out.print("Enter number of hours slept on " + days[i] + ": ");
            // put the hours slept in the hours array at index (i)
            hours[i] = consoleScanner.nextDouble();
            sum += hours[i];
            if (hours[i] >= 7 && hours[i] < 10)
                recommended++;
            else if (hours[i] < 6 || hours[i] > 11)
                notRecommended++;
            else
                appropiate++;
        }
        average = sum / hours.length;
        System.out.println("\nTotal number of hours slept last week : " + sum);
        System.out.println("Average of hours slept per night : " + average);
        System.out.println("\nAccording to the NSF, last week, you slept:");
        System.out.println(recommended + ((recommended == 1) ? " night" : " nights") + " of \"recommended\" sleep");
        System.out.println(appropiate + ((appropiate == 1) ? " night" : " nights")+ " of \"appropiate\" sleep");
        System.out.println(
                notRecommended + ((notRecommended == 1) ? " night" : " nights") + " of \"not recommended\" sleep");
        System.out.print("\nOverall, your sleep health (on average) is ");
        if (average >= 7 && average < 10)
            System.out.println("\"recommended\"");
        else if (average < 6 || average > 11)
            System.out.println("\"not recommended\"");
        else
            System.out.println("\"appropriate\"");
        consoleScanner.close();
    }
   

}
