import java.text.NumberFormat;
import java.util.Scanner;


public class Tipping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

Scanner consoleScanner= new Scanner(System.in);
int tippercentage ;
double restaurantbill, totaltaxes, tipamount,totalamount;
NumberFormat currency = NumberFormat.getCurrencyInstance();

System.out.print("Please enter amount of restaurant bill " + " $");
restaurantbill= consoleScanner.nextDouble();

System.out.print("Please enter the tip percentage " + "(%) ");
tippercentage= consoleScanner.nextInt();

totaltaxes= (restaurantbill)*0.08;
System.out.println("\nThe total taxes are " + currency.format(totaltaxes));

tipamount= ((restaurantbill+totaltaxes)*tippercentage*0.01);
System.out.println("the total tip amount is "  +  currency.format(tipamount));

totalamount= (restaurantbill + tipamount + totaltaxes);
System.out.println("\nthe total amount to pay is " +   currency.format(totalamount));
	}

}
