import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AgeVerificationGUI extends JFrame
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
// Display a dialog to the user
       int response= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
        //response -1 = cancel, 0 means yeas, 1 means No
       switch (response) {
        case JOptionPane.CLOSED_OPTION:
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);
            int response1= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response2= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response3= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response4= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response5= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response6= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response7= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response8= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response9= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response10= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response11= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response12= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response13= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response14= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response15= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response16= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response17= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response18= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response19= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response20= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);

            int response21= JOptionPane.showConfirmDialog(null, "Are you 21 years of age or older?", "Age Verification", JOptionPane.YES_NO_OPTION);
            JOptionPane.showMessageDialog(null, "You must answer the question", "Aversion Detected", JOptionPane.ERROR_MESSAGE);
            
            default:
                JOptionPane.showMessageDialog(null, "Minor Detected", "You shall not pass!", JOptionPane.ERROR_MESSAGE);


            break;
        case JOptionPane.NO_OPTION:
            JOptionPane.showMessageDialog(null, "Minor Detected", "You shall not pass!", JOptionPane.ERROR_MESSAGE);
            break;
        case JOptionPane.YES_OPTION:
           JOptionPane.showMessageDialog(null, "Proceed on adult!", "You are an adult", JOptionPane.INFORMATION_MESSAGE);
           
            break;
        
    }
    
}
}