
public class CreditCardDemo
{

    public static void main(String[] args)
    {
        // create two creditCard objects
        CreditCard card1 = new CreditCard(CardNetwork.VISA, "1213 4567 8903 3435", "User 1", "11/2017", "123");
        CreditCard card2 = new CreditCard(CardNetwork.VISA, "1213 4567 8903 3435", "User 2", "11/2017", "123");
        
        System.out.println(card1);
        System.out.println(card2);
        
        if(card1.equals(card2)){
            System.out.println("The cards are the same!");
        }
            else
                System.out.println("The cards are different :(");
        card2.setcardholder("user 1");
        
                
            System.out.println(card1);
            System.out.println(card2);
            
            if(card1.equals(card2)){
                System.out.println("The cards are the same!");
            }
                else
                    System.out.println("The cards are different :(");
        }
        
    }

