
public enum CardNetwork
{
VISA,
AMEX,
DISCOVER,
MASTERCARD,
}
