import java.text.DecimalFormat;
import java.util.Scanner;

public class GradingApp
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
int  numgrades=0,numAs =0, numBs=0,numCs=0, numDs=0, numFs=0;
double average, low= Double.MAX_VALUE, high = Double.MIN_VALUE,input, sum=0;
Scanner consoleScanner = new Scanner(System.in);
DecimalFormat oneDp = new DecimalFormat("0.0");
DecimalFormat zeroDps = new DecimalFormat("0");

System.out.println("Please input grades one per line (or type -1 to quit):");

do{
    input = consoleScanner.nextDouble();
    if(input >=0)
    {
        numgrades++;
        sum += input;
        if(input >=90)
            numAs++;
        else if(input >=80)
        numBs++;
        else if(input>=70)
        numCs++;
        else if(input>=60)
            numDs++;
        else if(input<60)
            numFs++;
        //Lets make a decision to see if the input < low
        if(input<low)
            low= input;
        if (input> high)
            high = input;
        
    }
   
}
while(input !=-1);
System.out.println("Total number of grades = " + numgrades);
System.out.println("Number of A's= " + numAs + "\n" +
"Number of B's = " + numBs +"\n" + 
"Number of C's = " + numCs +"\n" +
"Number of D's = " + numDs +"\n" +
"Number of F's = " + numFs +"\n" );   
average = sum/numgrades;
System.out.println("Low Grade = "+ zeroDps.format(low)+ "%");
System.out.println("Class Average = "+ oneDp.format(average)+ "%");
System.out.println("High Grade = "+ zeroDps.format(high)+ "%");


}

}
