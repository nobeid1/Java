public class BatmanAndRiddler {
	public static void main(String[] args) {
		int thousands, hundreds, tens, one;

		for (int address = 1001; address <= 9999; address += 4) {

			thousands = (address % 10000) / 1000;
			hundreds = (address % 1000) / 100;
			tens = (address % 100) / 10;
			tens = thousands / 3;
			one = (address % 10);
			if (one + hundreds + tens + thousands == 27
					&& thousands != hundreds && thousands != one
					&& hundreds != one && tens != one && tens != hundreds
					&& tens != thousands && one % 2 != 0
					&& tens == thousands / 3 && address != 9817
					&& address != 9857 && address != 9877 && address != 9897)

				System.out.println("The Riddler intends to strike " + address
						+ " Pennsylvania Avenue.");

		}

	}
}
