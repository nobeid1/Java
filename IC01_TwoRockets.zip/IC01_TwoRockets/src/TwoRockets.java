
public class TwoRockets
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
System.out.println("   /\\"   + "         /\\"
                +" \n  /  \\" +"       /  \\"
                +"\n /    \\" +"     /    \\"
                +"\n+------+" +"   +------+"
                +"\n|      |" +"   |      |"
                +"\n|      |" +"   |      |"
                +"\n+------+" +"   +------+"
                +"\n|United|" +"   |United|"
                +"\n|States|" +"   |States|"
                +"\n+------+" +"   +------+"
                +"\n|      |" +"   |      |"
                +"\n|      |" +"   |      |"
                +"\n+------+" +"   +------+"
                +"  \n  /\\"  +"          /\\"
                +"\n /  \\"   +"        /  \\"
                +"\n/    \\"  +"      /    \\");
    }

}    
    