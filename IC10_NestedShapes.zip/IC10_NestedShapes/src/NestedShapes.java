
public class NestedShapes
{

    public static void main(String[] args)
    {
       for(int j=1;j<=4;j++)
       {
           for (int i=1; i<=4;i++)
           {
               System.out.print("*");
           }
           System.out.println();
       }
      
       System.out.println();
       {
       }
for (int row= 1; row<=4;row++)
{
    for (int i=1; i<=4; i++)
    {
   System.out.print(row );
}
System.out.println();
}

System.out.println();
for(int row= 1; row<=4;row++)
{
    for(int col=1; col<=row;col++)
    {
        System.out.print("*");
    }
    System.out.println();
}
System.out.println();
for (int row = 1;row<=4;row++)
{
    for(int i=1; i<=row;i++)
    {
        System.out.print(row);
    }
    System.out.println();
}

       }
}