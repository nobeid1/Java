import java.util.Scanner;

public class ChangeMaker
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        
        int cents, quarters, dimes, nickels, pennies;
        Scanner consoleScanner = new Scanner(System.in);
        
        System.out.println("Enter a whole number from 1 to 99.");
        System.out.println("I will find a combination of coins to equal that amount of change ");
        cents= consoleScanner.nextInt();
        
       System.out.print("\n");
       System.out.println(cents + " cents in coins can be given as:");
        // 3 = 87 / 25
        quarters = cents / 25;
        // 12 = 87 % 25
        // NEW = OLD % 25
        cents = cents % 25;
        
        dimes = cents / 10;
        cents = cents % 10;
       
        nickels = cents / 5;
        cents = cents % 5;
        
        pennies= cents / 1;
        cents = cents % 1;
        
        
        System.out.println(quarters + " quarter(s)");
        System.out.println(dimes + " dime(s)");
        System.out.println(nickels + " nickel(s)");
        System.out.println(pennies + " penny(ies)");
        
                

    }

}
