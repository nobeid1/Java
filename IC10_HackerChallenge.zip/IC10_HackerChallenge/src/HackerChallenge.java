import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;

public class HackerChallenge extends JApplet {
	public void init() {
		setSize(500, 500);
	}

	public static final int FaceWidth = 50;
	public static final int FaceHeight = 50;
	public static final int EYESWIDTH = 10;
	public static final int EYESHEIGHT = 10;
	public static final int NoseWidth = 5;
	public static final int NoseHeight = 5;
	public static final int WidthOfSmile = 20;
	public static final int HeightOfSmile = 20;
	public static final int RotationOfSmile = 180;
	public static final int DegreeOfSmile = 180;

	public void paint(Graphics canvas) {
		int x = 0, y = 0;
				for (int face = 1; face <= 10; face++) {
				canvas.setColor(Color.ORANGE);
				canvas.fillOval(x, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.blue);
				canvas.fillOval(50, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.ORANGE);
				canvas.fillOval(100, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.BLUE);
				canvas.fillOval(150, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.ORANGE);
				canvas.fillOval(200, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.BLUE);
				canvas.fillOval(250, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.ORANGE);
				canvas.fillOval(300, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.BLUE);
				canvas.fillOval(350, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.ORANGE);
				canvas.fillOval(400, y, FaceWidth, FaceHeight);
				canvas.setColor(Color.BLUE);
				canvas.fillOval(450, y, FaceWidth, FaceHeight);
				y += 50;
							}
				int  ya = 10;
								for (int eye = 1; eye <= 10; eye++) 
				{
					
					canvas.setColor(Color.BLACK);
					canvas.fillOval(13, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(60, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(107, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(158, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(210, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(258, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(306, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(358, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(410, ya, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(458, ya, EYESWIDTH, EYESHEIGHT);
									ya+=50;
				
				}
				int xb = 35, yb = 10;
				for (int eye = 1; eye <= 10; eye++) {
						
					canvas.setColor(Color.BLACK);
					canvas.fillOval(xb, yb, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(80, yb, EYESWIDTH, EYESHEIGHT);		
					canvas.fillOval(130, yb, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(178, yb, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(231, yb, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(284, yb, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(337, yb, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(386, yb, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(435, yb, EYESWIDTH, EYESHEIGHT);
					canvas.fillOval(484, yb, EYESWIDTH, EYESHEIGHT);
					yb+=50;

			}
				int xc = 15, yc = 25;
				for (int smile = 1; smile <= 10; smile++) {
					canvas.setColor(Color.BLACK);
					canvas.drawArc(xc, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);		
					canvas.drawArc(63, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					canvas.drawArc(112, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					canvas.drawArc(165, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					canvas.drawArc(215, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					canvas.drawArc(265, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					canvas.drawArc(315, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					canvas.drawArc(365, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					canvas.drawArc(415, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					canvas.drawArc(465, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);
					
					yc+=50;
					
		}
				int xd = 24, yd = 29;
				for (int nose = 1; nose <= 10; nose++) {
					canvas.setColor(Color.BLACK);
					canvas.fillRect(xd, yd, NoseWidth, NoseHeight);		
					canvas.fillRect(70, yd, NoseWidth, NoseHeight);		
					canvas.fillRect(119, yd, NoseWidth, NoseHeight);		
					canvas.fillRect(172, yd, NoseWidth, NoseHeight);	
					canvas.fillRect(222, yd, NoseWidth, NoseHeight);		
					canvas.fillRect(273, yd, NoseWidth, NoseHeight);		
					canvas.fillRect(323, yd, NoseWidth, NoseHeight);		
					canvas.fillRect(370, yd, NoseWidth, NoseHeight);	
					canvas.fillRect(422, yd, NoseWidth, NoseHeight);
					canvas.fillRect(472, yd, NoseWidth, NoseHeight);	
					yd+=50;
					
		}
		}

}