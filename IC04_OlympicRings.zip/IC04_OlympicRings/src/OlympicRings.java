import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JApplet;

public class OlympicRings extends JApplet
{

    public void init()
    {//          w    h
        setSize(300, 200);
    }

public void paint(Graphics canvas)
{
    Graphics2D g2 = (Graphics2D) canvas;
    g2.setStroke(new BasicStroke(6));
    canvas.setColor(Color.BLUE);
    canvas.drawOval( 10,  5 , 80, 80);
    
    canvas.setColor(Color.BLACK);
    canvas.drawOval(100, 5 , 80, 80);
    
    canvas.setColor(Color.ORANGE);
    canvas.drawOval(55, 50, 80, 80);
    
    canvas.setColor(Color.RED);
    canvas.drawOval(190, 5, 80, 80);
    
    canvas.setColor(Color.GREEN);
    canvas.drawOval(142, 50 , 80, 80);
}
}