package edu.orangecoastcollege.cs170.nobeid1.ic19;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;

public class LATemps
{
public static final int DAYS_IN_OCT = 31;
    public static void main(String[] args)
    {
        int[] temps = new int[DAYS_IN_OCT];
        double sum = 0.0, average;
        int mode=0;
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat twoDP = new DecimalFormat("#.00");
        
        for (int day = 0; day < temps.length; day++){
            System.out.print("Please enter daily high for October " + (day < 9 ? "0":"") + (day+1) + ": ");
            temps[day] = consoleScanner.nextInt();
            sum += temps[day];
        }
        Arrays.sort(temps);
        average =sum/ DAYS_IN_OCT;
        int maxTemp= temps[30];
        int[] tallies = new int[maxTemp+1];
        
        int maxTally = 0;
        
        for (int singleTemp : temps){
            tallies[singleTemp]++;
            if(tallies[singleTemp]>maxTally)
            {
                maxTally = tallies[singleTemp];
                mode = singleTemp;
                }            
            }
       
        
   
        System.out.println("\n~~~~~~~~~~~Temperature Statistics~~~~~~~~~~");
       
        
       
        
       
        
        System.out.println("October's highest daily temperature was: " + temps[30]);
        System.out.println("October's average high temperature was: " + twoDP.format(average));
        System.out.println("October's most frequent high temp: " + mode);
        
        
    
    }

}

