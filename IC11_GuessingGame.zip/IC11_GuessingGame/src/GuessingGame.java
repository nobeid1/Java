import java.util.Random;
import java.util.Scanner;

public class GuessingGame
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
Scanner consoleScanner = new Scanner(System.in);
Random rng = new Random();
int guess, answer,numCorrect=0,sumCorrect=0;

answer =rng.nextInt(90000) + 10000;

do
{
System.out.print("Please enter a 5-digit code(your guess): ");
guess = consoleScanner.nextInt();
String guessString = String.valueOf(guess);
String answerString = String.valueOf(answer);
for(int i=0;i<=4;i++){
    if(guessString.charAt(i) == answerString.charAt(i)){
        numCorrect++;
        sumCorrect += Character.getNumericValue(answerString.charAt(i));
    }
}
System.out.println("Number of Digits Correct: " + numCorrect);
System.out.println("Sum of Digits Correct: " + sumCorrect);
numCorrect=0;
sumCorrect=0;
}   
while(guess != answer);
}
}