package edu.orangecoastcollege.cs170.nobeid1.ic21;

import java.util.Scanner;

public class Sudoku
{
	   public static int[][] initialPuzzle = {

           { 9, 0, 0, 8, 0, 5, 0, 0, 6 },

           { 1, 0, 3, 0, 0, 0, 5, 0, 4 },

           { 0, 6, 0, 0, 2, 0, 0, 7, 0 },

           { 0, 0, 7, 1, 0, 8, 6, 0, 0 },

           { 4, 0, 0, 0, 0, 0, 0, 0, 9 },

           { 0, 0, 9, 7, 0, 3, 1, 0, 0 },

           { 0, 9, 0, 0, 1, 0, 0, 6, 0 },

           { 3, 0, 2, 0, 0, 0, 4, 0, 7 },

           { 5, 0, 0, 3, 0, 2, 0, 0, 1 } };

   public static int[][] solvedPuzzle = {

           { 9, 7, 4, 8, 3, 5, 2, 1, 6 },

           { 1, 2, 3, 9, 6, 7, 5, 8, 4 },

           { 8, 6, 5, 4, 2, 1, 9, 7, 3 },

           { 2, 3, 7, 1, 9, 8, 6, 4, 5 },

           { 4, 8, 1, 2, 5, 6, 7, 3, 9 },

           { 6, 5, 9, 7, 4, 3, 1, 2, 8 },

           { 7, 9, 8, 5, 1, 4, 3, 6, 2 },

           { 3, 1, 2, 6, 8, 9, 4, 5, 7 },

           { 5, 4, 6, 3, 7, 2, 8, 9, 1 } };
   public static final int Rows = 9;
   public static final int Cols = 9;
   public static int[][] workingPuzzle = new int[Rows][Cols];

   // Miscellaneous method called resetPuzzle , that rests the workingPuzzle
   // to all elements in the initalPuzzle
   public static void resetPuzzle()
   {
       // copy all the elements from the initalPuzzle to workingPuzzle
       for (int i = 0; i < Rows; i++)
       {
           for (int j = 0; j < Cols; j++)
           {
               workingPuzzle[i][j] = initialPuzzle[i][j];
           }
       }

   }

   public static void printPuzzle()
   {
       System.out.println(" C 1 2 3 4 5 6 7 8 9");
       System.out.println("R  -----------------");

       // Loop through printPuzzle and print bored (formatted)
       for (int i = 0; i < Rows; i++)
       {
           // Before any of the colum values get print , show the header
           System.out.print((i + 1) + " |");
           for (int j = 0; j < Cols; j++)
           {
               // if the value is 0, print a.
               if (workingPuzzle[i][j] == 0)
                   System.out.print(". ");
               else
                   System.out.print(workingPuzzle[i][j] + " ");
           }
           System.out.println();
       }

   }

   // Method (name: gameIsWon) determins whether the workingPuzzle
   // is exactly the same as the SovePuzzle
   public static boolean gameIsWon()
   {
       for (int i = 0; i < Rows; i++)
       {
           for (int j = 0; j < Cols; j++)
           {
               if (workingPuzzle[i][j] != solvedPuzzle[i][j]) 
                   return false;
           }
       }
       // Made though all 81 Values, so return true 
       return true;
   }

   public static void main(String[] args)
   {
       String input;
       int row, col;
       Scanner consoleScanner = new Scanner(System.in);
       resetPuzzle();
       do
       {
           printPuzzle();
           System.out.println("What would you like to do ?");
           System.out.println("Set a square (S), Reset Puzzle (R), Quit (Q)");
           input = consoleScanner.next().toUpperCase();
           switch (input)
           {
               case "S":
                   System.out.println("Which row(1-9) and whichcolum (1-9) do you want to change?");
                   row = consoleScanner.nextInt() - 1;
                   col = consoleScanner.nextInt() - 1;
                   System.out.println("What should the Value (1-9)be?");
                   workingPuzzle[row][col] = consoleScanner.nextInt();
                   if (gameIsWon())
                   {
                       // congratulate ( in your way) the User! 
                   	int i;
                       for (i = 0; i < 10; i++)
                             System.out.println("Wohooo! You did it ... Way to GO!!");
                   	
                       System.exit(0);
                   }

                   break;
               case "R":
                   resetPuzzle();
                   break;
               case "Q":
                   System.out.println("Thanks for playing!");
                   break;
           }

       }
       while (!input.equalsIgnoreCase("q"));

   }
}
