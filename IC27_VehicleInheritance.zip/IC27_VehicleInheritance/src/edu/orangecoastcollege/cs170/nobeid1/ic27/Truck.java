package edu.orangecoastcollege.cs170.nobeid1.ic27;

import java.io.Serializable;

public class Truck extends Vehicle{
private double mloadCapacity;
private double mtowingCapacity;
public Truck(int mHoursePower, String mmanufacturerName, int mnumberCylinders,
		Person mowner, int mloadCapacity, int mtowingCapacity) {
	super(mHoursePower, mmanufacturerName, mnumberCylinders, mowner);
	this.mloadCapacity = mloadCapacity;
	this.mtowingCapacity = mtowingCapacity;
}
public Truck(Truck other) {
	super(other.mHoursePower, other.mmanufacturerName, other.mnumberCylinders, other.mowner);
	this.mloadCapacity = other.mloadCapacity;
	this.mtowingCapacity = other.mtowingCapacity;
}
public double getMloadCapacity() {
	return mloadCapacity;
}
public void setMloadCapacity(int mloadCapacity) {
	this.mloadCapacity = mloadCapacity;
}
public double getMtowingCapacity() {
	return mtowingCapacity;
}
public void setMtowingCapacity(int mtowingCapacity) {
	this.mtowingCapacity = mtowingCapacity;
}


@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (!super.equals(obj))
		return false;
	if (getClass() != obj.getClass())
		return false;
	Truck other = (Truck) obj;
	if (mloadCapacity != other.mloadCapacity)
		return false;
	if (mtowingCapacity != other.mtowingCapacity)
		return false;
	return true;
}
@Override
public String toString() {
	 return "Truck [" +mHoursePower + ", "+ mmanufacturerName + ", " + mnumberCylinders+ ", "+ mowner+ ", "+ mloadCapacity+ ", " + mtowingCapacity+"]";
}

}
