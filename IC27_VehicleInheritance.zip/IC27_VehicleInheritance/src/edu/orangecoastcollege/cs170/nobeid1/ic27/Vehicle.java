package edu.orangecoastcollege.cs170.nobeid1.ic27;

import java.io.Serializable;

public class Vehicle implements Serializable {
protected int mHoursePower;
protected String mmanufacturerName;
protected int mnumberCylinders;
protected Person mowner;
public Vehicle(int mHoursePower, String mmanufacturerName,
		int mnumberCylinders, Person mowner) {
	super();
	this.mHoursePower = mHoursePower;
	this.mmanufacturerName = mmanufacturerName;
	this.mnumberCylinders = mnumberCylinders;
	this.mowner = mowner;
}
public Vehicle(Vehicle other) {
	super();
	this.mHoursePower = other.mHoursePower;
	this.mmanufacturerName = other.mmanufacturerName;
	this.mnumberCylinders = other.mnumberCylinders;
	this.mowner = other.mowner;
}
public int getmHoursePower() {
	return mHoursePower;
}
public void setmHoursePower(int mHoursePower) {
	this.mHoursePower = mHoursePower;
}
public String getMmanufacturerName() {
	return mmanufacturerName;
}
public void setMmanufacturerName(String mmanufacturerName) {
	this.mmanufacturerName = mmanufacturerName;
}
public Person getMowner() {
	return mowner;
}
public void setMowner(Person mowner) {
	this.mowner = mowner;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + mHoursePower;
	result = prime * result
			+ ((mmanufacturerName == null) ? 0 : mmanufacturerName.hashCode());
	result = prime * result + mnumberCylinders;
	result = prime * result + ((mowner == null) ? 0 : mowner.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Vehicle other = (Vehicle) obj;
	if (mHoursePower != other.mHoursePower)
		return false;
	if (mmanufacturerName == null) {
		if (other.mmanufacturerName != null)
			return false;
	} else if (!mmanufacturerName.equals(other.mmanufacturerName))
		return false;
	if (mnumberCylinders != other.mnumberCylinders)
		return false;
	if (mowner == null) {
		if (other.mowner != null)
			return false;
	} else if (!mowner.equals(other.mowner))
		return false;
	return true;
}
@Override
public String toString() {
	return "Vehicle [" +mHoursePower + ", "+ mmanufacturerName + ", " + mnumberCylinders+ ", "+ mowner+ "]";
			
}

}
