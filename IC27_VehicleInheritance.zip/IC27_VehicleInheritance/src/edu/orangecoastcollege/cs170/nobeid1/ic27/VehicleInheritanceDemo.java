package edu.orangecoastcollege.cs170.nobeid1.ic27;

import java.util.ArrayList;
import java.util.Scanner;


public class VehicleInheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Vehicle> allVehicleList = new ArrayList<>();
String name;
Person mj= new Person("Mr.","Michael Jordan");
Person Noa= new Person("Miss","Nasim");
Vehicle car1 = new Vehicle(300,"BMW",6,Noa);
Truck truck= new Truck(200,"Ford",4,mj,200,3);
System.out.println(car1);
System.out.println(truck);
Scanner consoleScanner = new Scanner(System.in);
do{
	consoleScanner.reset();
	System.out.print("Car or Truck (or type \"quit\")? ");
	String select = consoleScanner.nextLine();
	if(select.equalsIgnoreCase("quit"))
		break;
	if(select.equalsIgnoreCase("car")){
	System.out.print("Make of your Car: ");
	name = consoleScanner.nextLine();
	System.out.print("Enter name of Model: ");
	String make = consoleScanner.nextLine();
	System.out.print("How many Cylinders: ");
	int cynlinders = consoleScanner.nextInt();
	System.out.print("Please enter Horse Power: ");
	int horsePower = consoleScanner.nextInt();
	consoleScanner.nextLine();
	System.out.print("Please enter Owner: ");
	String ownerName = consoleScanner.nextLine();
	System.out.print("Please enter your sex? ");
	String sex = consoleScanner.nextLine();
	String honorific;
	if(sex.equalsIgnoreCase("male"))
		honorific = "Mr.";
	else{
		System.out.print("Please enter Your type of Miss or Mrs.");
		honorific = consoleScanner.nextLine().equalsIgnoreCase("Miss") ? "Miss":"Mrs.";
	}
	allVehicleList.add(new Vehicle(horsePower, make, cynlinders,new Person(honorific, ownerName)));
	}
	else{
		System.out.print("Name of Truck (or type \"quit\"): ");
		name = consoleScanner.nextLine();
		if(name.equalsIgnoreCase("quit"))
			break;
		System.out.print("enter name of dealer: ");
		String make = consoleScanner.nextLine();
		System.out.print("Please Cylinders: ");
		int cynlinders = consoleScanner.nextInt();
		System.out.print("Please enter Horse Power: ");
		int horsePower = consoleScanner.nextInt();
		consoleScanner.nextLine();
		System.out.print("Please enter Owner: ");
		String ownerName = consoleScanner.nextLine();
		String sex = consoleScanner.nextLine();
		String honorific;
		if(sex.equalsIgnoreCase("male"))
			honorific = "Mr.";
		else{
			System.out.print("Please enter Your type of Miss or Mrs.");
			honorific = consoleScanner.nextLine().equalsIgnoreCase("Miss") ? "Miss":"Mrs.";
		}
		allVehicleList.add(new Vehicle(horsePower, make, cynlinders,new Person(honorific, ownerName)));
	}
	System.out.println();
}while(!name.equalsIgnoreCase("quit"));
consoleScanner.close();
System.out.println();
for(Vehicle v:allVehicleList){
	System.out.println(v);
	System.out.println();
}
}
	}


