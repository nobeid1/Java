import java.util.Scanner;


public class DateFormat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String usDate, month, day, year,euDate;
	        Scanner consoleScanner = new Scanner(System.in);
	        
	        System.out.println("Please enter the date (format MM/DD/YYYY) and include the forward slashes: ");
	        usDate = consoleScanner.nextLine();
	        
	        month = usDate.substring(0,2);
	        day = usDate.substring(3,5);
	        year= usDate.substring(6);
	        
	        System.out.println("\nIn the European format, DD.MM.YYYY, this date is:" );
	        
	        System.out.println(day + "." + month + "."+ year);
	       
	        day = usDate.substring(0,2);
	        month = usDate.substring(3,5);	      
	        year= usDate.substring(6);
	              
	        	        
	        consoleScanner.close();
	}

}
