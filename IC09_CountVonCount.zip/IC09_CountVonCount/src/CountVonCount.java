import java.util.Scanner;

public class CountVonCount
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub

        int magicNumber;
        Scanner consoleScanner = new Scanner(System.in);
        System.out.println("Count Von Count: What is the magic number?");
        magicNumber = consoleScanner.nextInt();
        if (magicNumber <= 0)
        {
            System.err.println("I'm sorry, but the Count von Count only counts positive numbers!  Muhahahaha");
            System.exit(0);
        }

        for (int i = 1; i < magicNumber; i++)
        {
            System.out.print(i + ",");

        }
        System.out.println(magicNumber + "\n" + magicNumber + "! " + magicNumber + " is the magic number of the day. "
                + magicNumber + " dancing vegetables are here to celebrate with me! I love dancing vegetables!");

    }
}
