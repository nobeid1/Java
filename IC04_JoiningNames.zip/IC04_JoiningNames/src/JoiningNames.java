import java.util.Scanner;

import javafx.scene.chart.ValueAxis;

public class JoiningNames
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
       // Step 1) Declare all variables needed
        String first, middle, last;
Scanner consoleScanner = new Scanner(System.in);
System.out.print("Please enter your first name: ");
first = consoleScanner.nextLine();

System.out.print("Please enter your middle initial: ");
middle = consoleScanner.nextLine();

System.out.print("Please enter your last name: ");
last = consoleScanner.nextLine();

System.out.println("\n" + first + "(length = " + first.length() + ")");

System.out.println(  middle + "(length = " + middle.length() + ")");

System.out.println( last + "(length = " + last.length() + ")");

System.out.println("\n" + last.toUpperCase() + "," + first.toUpperCase() + ","  + middle.toUpperCase());

// ***Remeber to close your consoleScanner
consoleScanner.close();

    }

}
