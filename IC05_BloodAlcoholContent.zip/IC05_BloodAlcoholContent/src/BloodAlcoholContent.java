import java.text.DecimalFormat;
import java.util.Scanner;

public class BloodAlcoholContent
{
    public static final double lEGAL_lIMIT = 0.08;
    public static final double OUNCES_ALCOHOL = 1.5;
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub

        double drinks, BAC, weight;
        Scanner consoleScanner = new Scanner(System.in);
        DecimalFormat threeDPs = new DecimalFormat("#.000");

        System.out.print("Enter the number of drinksic drinks consumed: ");

        drinks = consoleScanner.nextDouble();
        System.out.print("Please enter your wieght in lbs: ");
        weight = consoleScanner.nextDouble();
        BAC = (4.136 * drinks * OUNCES_ALCOHOL) / weight;
        if (BAC >= lEGAL_lIMIT )
        {
            System.out.println("\nYour BAC is " +  threeDPs.format(BAC) );

            System.out.println("According to the state of California, your intoxicated. Do not drive");
        }   
        else 
        {
        	System.out.println("\nYour BAC is " +  threeDPs.format(BAC) );
            System.out.println("You are legal to drive on the road. Drive safe!");
        }
        
    }
    



}
