import java.util.Random;
import java.util.Scanner;

public class Magic8Ball
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        String question, response;
        int Answer;
        Random rng = new Random();
        Scanner consoleScanner = new Scanner(System.in);
        do 
        {
        System.out.println("What question would you like to ask the enhanced Magic 8 ball?");
        question = consoleScanner.nextLine();
        Answer =rng.nextInt(8)+1;
        switch(Answer)
        {
        case 1:
        System.out.println("It is certain");
        System.out.println("This answer is: Positive");
        break;
        case 2:
           System.out.println("It is decidedly so"); 
           System.out.println("This answer is: Positive");
           break;
        case 3:
            System.out.println("Most likely");
            System.out.println("This answer is: Positive");
        break;
        case 4:
            System.out.println("Signs point to yes");
            System.out.println("This answer is: Positive");
            break;
        case 5:
            System.out.println("Reply hazy, try again");
            System.out.println("This answer is: Neutral");
break;
        case 6:
System.out.println("Ask again later");
System.out.println("This answer is: Neutral");
break;
        case 7:
System.out.println("Don't count on it");
System.out.println("This answer is: Negative");
break;
        case 8: 
            System.out.println("My sources say no");
            System.out.println("This answer is: Negative");
break;
        case 9:
            System.out.println("Yes");
            System.out.println("This answer is: Positive");
            break;
            case 10:
               System.out.println("Better not tell you now");   
               System.out.println("This answer is: Neutral");
               break;
            case 11:
                System.out.println("As I see it, yes");
                System.out.println("This answer is: Positive");
            break;
            case 12:
                System.out.println("Cannot predict now");
                System.out.println("This answer is: Neutral");
                break;
            case 13:
                System.out.println("Concentrate and ask again");
                System.out.println("This answer is: Neutral");
    break;
            case 14:
    System.out.println("My reply is no");
    System.out.println("This answer is: Negative");
    break;
            case 15:
    System.out.println("Outlook not so good");
    System.out.println("This answer is: Negative");
    break;
            case 16: 
                System.out.println("Very doubtful");
                System.out.println("This answer is: Negative");
                    break;
            case 17:
                System.out.println("Yes definitley");
                System.out.println("This answer is: Positive");
    break;
            case 18:
    System.out.println("You may rely on it");
    System.out.println("This answer is: Positive");
    break;
            case 19:
    System.out.println("Outlook good");
    System.out.println("This answer is: Positive");
    break;
            case 20: 
                System.out.println("Without a doubt");
                System.out.println("This answer is: Positive");                
    break;
        }
 
        System.out.println("\nWould you like to ask another question?");
        response = consoleScanner.nextLine().toUpperCase();
        System.out.println("\n");
        } 
        while(response.startsWith("Y"));
        
         
       System.out.println("Thank you for playing the Magic 8 Ball.");
       consoleScanner.close();
    }

}
