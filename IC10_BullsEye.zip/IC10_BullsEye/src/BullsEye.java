import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;

public class BullsEye extends JApplet
    {
        public void init(){
            setSize(350,350);
        }
        public void paint(Graphics canvas){
            int x=0, y=0, w=350, h=350;
            for (int i = 1; i<=7;i++)
            {
                if(i%2 !=0)
                    
            canvas.setColor(Color.RED);
                else 
                    canvas.setColor(Color.WHITE);
            canvas.fillOval(x, y, w,h);
            // x and y should increase by 25
            x+= 25;
            y+=25;
            w-=50;
            h-=50;
           
            
        }
        
    }
    }

