package edu.orangecoastcollege.cs170.nobeid1.FinalExam;

import java.io.Serializable;

public class Train extends vehicle implements Serializable
{
    private int mCookingTemp;
    private int mType;
    
    public Train(int calories,int carbohydrates,String name,int cookingTemp, int type) throws trainException
    {
        super();
        mCalories=calories;
        mCarbohydrates=carbohydrates;
        mName=name;
        mCookingTemp = cookingTemp;
        if(type!=1&&type!=2)
        throw new trainException();
        else{
            mType = type;
        }
        
    }

    public int getCookingTemp()
    {
        return mCookingTemp;
    }

    public void setCookingTemp(int cookingTemp)
    {
        mCookingTemp = cookingTemp;
    }

    public int getType() 
    {
        return mType;
    }

    public void setType(int type) throws trainException
    {
        if(type!=1&&type!=2)
            throw new trainException();
        else
        mType = type;
    }

    @Override
    public int hashCode()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + mCookingTemp;
        result = prime * result + mType;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Train other = (Train) obj;
        if (mCookingTemp != other.mCookingTemp) return false;
        if (mType != other.mType) return false;
        return true;
    }

    @Override
    public String toString()
   
    {
        if(mType==1){
            System.out.print("");
        return  "Meat" + ": " + mName+ ", "+mCalories + " calories, " + mCarbohydrates + "g Carbs, "+ mCookingTemp + " degrees F";}
        else if(mType==2)
            System.out.print("");
        return  "Seafood" + ": " + mName+ ", "+mCalories + " calories, " + mCarbohydrates + " g Carbs, "+ mCookingTemp + " degrees F";
    }

    
}
