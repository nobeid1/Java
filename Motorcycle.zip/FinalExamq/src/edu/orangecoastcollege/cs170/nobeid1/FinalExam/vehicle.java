package edu.orangecoastcollege.cs170.nobeid1.FinalExam;

import java.io.Serializable;

public abstract class vehicle implements Serializable
{
protected int mCalories;
protected int mCarbohydrates;
protected String mName;
public int getCalories()
{
    return mCalories;
}
public void setCalories(int calories)
{
    mCalories = calories;
}
public int getCarbohydrates()
{
    return mCarbohydrates;
}
public void setCarbohydrates(int carbohydrates)
{
    mCarbohydrates = carbohydrates;
}
public String getName()
{
    return mName;
}
public void setName(String name)
{
    mName = name;
}


}
