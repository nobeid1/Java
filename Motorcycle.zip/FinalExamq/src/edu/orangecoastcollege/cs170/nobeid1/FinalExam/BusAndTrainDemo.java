package edu.orangecoastcollege.cs170.nobeid1.FinalExam;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class BusAndTrainDemo
{

    public static void main(String[] args)
    {
        ArrayList<vehicle> FoodList = new ArrayList<>();
        Scanner consoleScanner = new Scanner(System.in);
        int type;
        int cabo = 0;
     
        int input = 0;
        File binaryFile = new File("BusandTrain.dat");
        System.out.println("~~~~~~~~~~Welcome to the Paleo Food Journal~~~~~~~~~");
        if (binaryFile.exists())
        {
            try
            {
                ObjectInputStream FileReader = new ObjectInputStream(new FileInputStream(binaryFile));
                vehicle[] foodArray = (vehicle[]) FileReader.readObject();

                for (vehicle food : foodArray)
                {
                    FoodList.add(food);
                    System.out.println(food);
                }
                FileReader.close();
            }
            catch (FileNotFoundException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            catch (IOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            catch (ClassNotFoundException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        else
        {
            System.out.println("[No food eaten.  You must be hungry.]");
            
        }
        System.out.println("Total calories Eaten: " + totalCalories(FoodList));
        System.out.println("Number of organic fruits and veggies eaten: " + OrganicProduceConsumed(FoodList));
        do
        {
            System.out.println("********Options Menu*********");
            System.out.println("Enter (1) to record a meat");
            System.out.println("Enter (2) to record a produce");
            System.out.println("Enter (3) to quit");
            
          
            input = consoleScanner.nextInt();
            consoleScanner.nextLine();
            switch (input) {
                case 1: // Meat
                    String nameMeat = "";
                    int cookingTemp=0;
                    System.out.print("Enter (1) for Meat and (2) for Seafood: ");
                    
                    type = consoleScanner.nextInt();
                    consoleScanner.nextLine();
                    System.out.print("Please enter the Name of the Meat: ");
                    nameMeat = consoleScanner.nextLine();
                    System.out.print("Please enter the heat of the temperature: ");
                    cookingTemp = consoleScanner.nextInt();
                    System.out.print("How many Calories was it? ");
                    int calo = 0;
                    calo = consoleScanner.nextInt();
                    System.out.print("How many Carbohydrates? ");
              
                    cabo = consoleScanner.nextInt();

                    Train meat;
                    try {
                        meat = new Train(cabo, calo, nameMeat, cookingTemp, type);
                        FoodList.add(meat);
                    } catch (trainException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                  
                    break;
                case 2:
                    System.out.print("What was the name of the Produce eaten? ");
                    String name = consoleScanner.nextLine();
                    System.out.print("How many calories? ");
                    int cal = consoleScanner.nextInt();
                    System.out.print("How many CarboHydrates? ");
                    int carb = consoleScanner.nextInt();
                    Bus produce = new Bus(carb, cal, name, false);
                    System.out.print("Enter (1) for organic or (2) for non-Organic ");
                    produce.setOrganic(consoleScanner.nextInt() == 1 ? true : false);
                    FoodList.add(produce);
                    default:
                        System.out.println("Eat healthy and enjoy your break!");
                    break;
                                }

            

        }
        while (input != 3);
        try
        {
            ObjectOutputStream fileWriter = new ObjectOutputStream(new FileOutputStream(binaryFile));
            vehicle[] foodArray = new vehicle[FoodList.size()];
            FoodList.toArray(foodArray);
            fileWriter.writeObject(foodArray);
            fileWriter.close();

        }
        catch (FileNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static int totalCalories(ArrayList<vehicle> FoodList)
    {
int total=0;
for(vehicle food: FoodList)
    total+=food.getCalories();
    return total;

    }
    public static int OrganicProduceConsumed(ArrayList<vehicle> foodList) {
        int total = 0;
        for (vehicle paleoFoods : foodList) {
            if (paleoFoods instanceof Bus) {
                Bus p = (Bus) paleoFoods;
                if (p.getOrganic())
                    total += 1;
            }
        }
        return total;
    }
}
