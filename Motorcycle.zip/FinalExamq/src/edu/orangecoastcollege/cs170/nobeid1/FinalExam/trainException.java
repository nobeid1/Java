package edu.orangecoastcollege.cs170.nobeid1.FinalExam;

public class trainException extends Exception
{
public trainException(String message){
    super(message);
}
public trainException(){
    super("This is a mystery meat! Don't eat it!");
}
}
