
public class RatingScore {
	private String mcomments;
	private String mdescription;
	private double mmaxscore;
	private double mscore;

public RatingScore (String description, double score,String comments){
	mdescription = description;
	mscore = score;
	mmaxscore = 5.0;
	mcomments = comments;
	
}
public String getdescription(){
	return mdescription;
}
public double getscore()
{
	return mscore;
}
public  double getmaxscore()
{
	return mmaxscore;
}
public  String getcomments()
{
	return mcomments;
}
public void setdescription(String description ){
	mdescription = description;
	
}
public void setscore(double score ){
	mscore = score;
	}
public void setmaxscore(double maxscore ){
	mmaxscore = maxscore;
	}
public void setcomments(String  comments ){
	mcomments = comments;
	}
public String toString()
{
	String output = "Rating[" + mdescription + ", " + mscore + ", " + mmaxscore + ", "+ mcomments + "]";
	return output;
}
public boolean equals(RatingScore other)
{
	if(!mdescription.equalsIgnoreCase(other.mdescription) )
		return false;
	if(!mcomments.equalsIgnoreCase(other.mcomments))
		return false;
	if(mscore != other.mscore)
		return false;
	
	return true;
}

}
