
public class RatingScore_DEMO {
	public static void main(String[] args)
    {

		RatingScore user1 = new RatingScore("Hidden Figures movie",4.75,"Feel-good film with strong, humorous and independent characters.");
		RatingScore user2 = new RatingScore("Okay-ish",3.25,"It was fine");

		System.out.println(user1);
		System.out.println(user2);
		if(user1.equals(user2)){
			System.out.println("The ratings are the same!");
		}
			else
				System.out.println("The ratings are different :(");
		
		user2.setcomments("Feel-good film with strong, humorous and independent characters.");
		user2.setdescription("Hidden Figures movie");
		user1.setscore(4.50);
		user2.setscore(4.50);
		System.out.println(user1);
		System.out.println(user2);
		if(user1.equals(user2)){
			System.out.println("The ratings are the same!");
		}
			else
				System.out.println("The ratings are different :(");
    }
}
