import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JApplet;

public class LoopyFaces extends JApplet {
	public void init() {
		setSize(500, 500);
	}
	public static final int FaceWidth = 60;		
	public static final int FaceHeight = 60;		
	public static final int EYESWIDTH = 10;	
	public static final int EYESHEIGHT = 10;	
	public static final int NoseWidth = 5;	
	public static final int NoseHeight = 5;	
	public static final int WidthOfSmile = 50;	
	public static final int HeightOfSmile = 45;	
	public static final int RotationOfSmile = 180;	
	public static final int DegreeOfSmile = 180;	
	
	public void paint(Graphics canvas) {
		int x = 0, y = 0;
		for (int face = 1; face <= 10; face++) {
			if (face % 2 != 0)
				canvas.setColor(Color.ORANGE);
			else
				canvas.setColor(Color.BLUE);
			canvas.fillOval(x, y, FaceWidth, FaceHeight);
			x += 45;
			y += 45;
		}
		int xa = 13, ya = 10;
		for (int eye = 1; eye <= 10; eye++) {
			canvas.setColor(Color.BLACK);
			canvas.fillOval(xa, ya, EYESWIDTH, EYESHEIGHT);
					
			xa+=45;
			ya+=46;
			
		}
		int xb = 35, yb = 10;
		for (int eye = 1; eye <= 10; eye++) {
				
			canvas.setColor(Color.BLACK);
			canvas.fillOval(xb, yb, EYESWIDTH, EYESHEIGHT);
					
			xb+=45;
			yb+=46;

	}
		int xc = 5, yc = 8;
		for (int smile = 1; smile <= 10; smile++) {
			canvas.setColor(Color.BLACK);
			canvas.drawArc(xc, yc, WidthOfSmile,HeightOfSmile,RotationOfSmile,DegreeOfSmile);		
			xc+=45;
			yc+=45;
			
}
		int xd = 26, yd = 31;
		for (int nose = 1; nose <= 10; nose++) {
			canvas.setColor(Color.BLACK);
			canvas.fillRect(xd, yd, NoseWidth, NoseHeight);		
			xd+=45;
			yd+=45;
			
}
}
}
