import java.text.DecimalFormat;
import java.util.Scanner;

public class RealMetabolicRate
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub

        double weight,height,age,bmrfemale,bmrmale,barsfemale,barsmale,barcalories= 230.0;

        
        DecimalFormat zeroDPs = new DecimalFormat("0");
        
        Scanner consoleScanner= new Scanner(System.in);
        System.out.print("Please enter your weight (lb): ");
        weight= consoleScanner.nextDouble();
        
        System.out.print("Please enter your height (in): ");
        height= consoleScanner.nextDouble();
        
        System.out.print("Please enter your age: ");
        age= consoleScanner.nextDouble();
        
        bmrfemale= 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
        System.out.print("\nBMR (female): " +  zeroDPs.format(bmrfemale) + " calories ");
       
       
        
        bmrmale= 66 +(6.23 * weight)+(12.7 * height)-(6.8 * age);
        System.out.print("\nBMR (male) :  " + zeroDPs.format(bmrmale) + " calories\n");
        
        
        barsfemale= bmrfemale/ barcalories;
        barsmale= bmrmale/ barcalories;
        
        System.out.println("\nIf you are female, you need to consume " + zeroDPs.format(barsfemale) + " chocolate bars to maintain weight.");
       
        System.out.println("If you are male, you need to consume " + zeroDPs.format(barsmale) + " chocolate bars to maintain weight.");
        
        
    }
    

}
