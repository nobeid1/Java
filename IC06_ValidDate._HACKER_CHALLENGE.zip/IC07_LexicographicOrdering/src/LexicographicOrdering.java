import java.util.Arrays;
import java.util.Scanner;


public class LexicographicOrdering {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String One, Two, Three;
		Scanner consoleScanner= new Scanner(System.in);
		 System.out.println("Please enter three seperate stings (in any order):");
		 One = consoleScanner.next();
		 Two = consoleScanner.next();
		 Three = consoleScanner.next();
		
		 System.out.println("\nIn Lexicographic ordering, the strings you entered are;");
		 String[] strNames = new String[]{One,Two,Three};
		 Arrays.sort(strNames);
		 for(int i=0; i < strNames.length; i++){
             System.out.println(strNames[i]);
			
			}
			
			
		}
}



